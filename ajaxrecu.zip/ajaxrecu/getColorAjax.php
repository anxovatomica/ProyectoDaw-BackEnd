<?php
session_start();

$colores = ["red","blue","yellow","green"];

if(isset( $_GET["saved"]) ) {
    $color = $_SESSION["color"];

}else{
    $pos_aleat = rand(0, count($colores)-1 );
    $color =  $colores[$pos_aleat];
    
    $_SESSION["color"] = $color;
}

$longitud = strlen($color);

echo '{"color":"'.$color.'", "long":"'.$longitud.'"}';
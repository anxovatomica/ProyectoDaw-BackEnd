<?php 
session_start();

$_SESSION["usuario"] = '{"nombre":"Juan","apellido1":"Sense","apellido2":"Por","edad":"12"}';

//$param1 = $_GET["param1"];

//echo '{"mensaje":"AJAX WORKS '.$param1.'"}';
//$resposta='{"nombre":"Juan","apellido1":"Sense","apellido2":"Por","edad":"12"}';

$resposta =$_SESSION["usuario"];

echo ($resposta);

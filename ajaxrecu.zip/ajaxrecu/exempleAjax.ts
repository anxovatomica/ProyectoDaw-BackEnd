function getColorAjax(){
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","getColorAjax.php",true);
    xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange =function(){
        if(xmlhttp.readyState==4){
            respostaGetColorAjax(xmlhttp);
        }
    }
    xmlhttp.send();
}
function respostaGetColorAjax(xmlhttp){
    if(xmlhttp.status==200){
        let resposta = xmlhttp.responseText;
        let respJSON = JSON.parse(resposta);
        console.log(respJSON.color);

        let long = respJSON.long;
        document.getElementById("palabra").innerHTML="";
        for(let k=0; k<long;k++){
            let span = document.createElement("SPAN");
            span.id="letra"+k;
            span.innerHTML=" _ ";
            document.getElementById("palabra").appendChild(span);
        }
    }
}

function getColorGenerado(){
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","getColorAjax.php?saved=true",true);
    xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange =function(){
        if(xmlhttp.readyState==4){
            respostaGetColorAjax(xmlhttp);
        }
    }
    xmlhttp.send();
}

function getUsuariosAjax(){
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","getUsuarios.php",true);
    xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange=function(){
        if(xmlhttp.readyState==4){
            respostaUsuariosAjax(xmlhttp);
        }
    }
    xmlhttp.send();
}
function respostaUsuariosAjax(xmlhttp){
    if(xmlhttp.status==200){
        let resposta = xmlhttp.responseText;
        let respJSON = JSON.parse(resposta);
        console.log(respJSON);
        let usuarios = respJSON["usuarios"];
        
        for(let k=0; k< usuarios.length;k++){
            let nombre = usuarios[k]["nombre"];
            let apellid1 = usuarios[k]["apellido1"];
            console.log("Nom"+nombre+" apell1:"+apellid1);
        }

    }
}

function sendAjaxGet(){
    let xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET","getRespostaAjax.php?param1=55",true);
    xmlhttp.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange=function(){
        console.log("EStat Petició"+xmlhttp.readyState);
        if(xmlhttp.readyState==4){

            console.log("Resposta rebuda");
            repRespostaAjaxGet(xmlhttp);
        }
    }
    xmlhttp.send();

}
function repRespostaAjaxGet(xmlhttp:XMLHttpRequest){
    if(xmlhttp.status==200){ //el recurs existeix
        let resposta = xmlhttp.responseText;
        let respJSON = JSON.parse(resposta);

        let nombre = respJSON["nombre"];
        let apellido1 = respJSON["apellido1"];
        let apellido2 = respJSON["apellido2"];
        let edad = respJSON["edad"];

        document.getElementById("respAjax").innerHTML=`
        nombre:`+nombre+` <br/>
        apellido1:`+apellido1+` <br/>
        apellido2:`+apellido2+` <br/>
        edad:`+edad+` <br/>

        `;
     

    }
}
<?php 

$resposta=
'{"usuarios":[{"nombre":"Juan","apellido1":"Sense","apellido2":"Por","edad":"12"},'.
        '{"nombre":"Juana","apellido1":"De","apellido2":"Arco","edad":"17"}] }';
echo ($resposta);

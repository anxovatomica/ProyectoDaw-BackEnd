function getColorAjax() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "getColorAjax.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            respostaGetColorAjax(xmlhttp);
        }
    };
    xmlhttp.send();
}
function respostaGetColorAjax(xmlhttp) {
    if (xmlhttp.status == 200) {
        var resposta = xmlhttp.responseText;
        var respJSON = JSON.parse(resposta);
        console.log(respJSON.color);
        var long = respJSON.long;
        document.getElementById("palabra").innerHTML = "";
        for (var k = 0; k < long; k++) {
            var span = document.createElement("SPAN");
            span.id = "letra" + k;
            span.innerHTML = " _ ";
            document.getElementById("palabra").appendChild(span);
        }
    }
}
function getColorGenerado() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "getColorAjax.php?saved=true", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            respostaGetColorAjax(xmlhttp);
        }
    };
    xmlhttp.send();
}
function getUsuariosAjax() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "getUsuarios.php", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange = function () {
        if (xmlhttp.readyState == 4) {
            respostaUsuariosAjax(xmlhttp);
        }
    };
    xmlhttp.send();
}
function respostaUsuariosAjax(xmlhttp) {
    if (xmlhttp.status == 200) {
        var resposta = xmlhttp.responseText;
        var respJSON = JSON.parse(resposta);
        console.log(respJSON);
        var usuarios = respJSON["usuarios"];
        for (var k = 0; k < usuarios.length; k++) {
            var nombre = usuarios[k]["nombre"];
            var apellid1 = usuarios[k]["apellido1"];
            console.log("Nom" + nombre + " apell1:" + apellid1);
        }
    }
}
function sendAjaxGet() {
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", "getRespostaAjax.php?param1=55", true);
    xmlhttp.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xmlhttp.onreadystatechange = function () {
        console.log("EStat Petició" + xmlhttp.readyState);
        if (xmlhttp.readyState == 4) {
            console.log("Resposta rebuda");
            repRespostaAjaxGet(xmlhttp);
        }
    };
    xmlhttp.send();
}
function repRespostaAjaxGet(xmlhttp) {
    if (xmlhttp.status == 200) {
        var resposta = xmlhttp.responseText;
        var respJSON = JSON.parse(resposta);
        var nombre = respJSON["nombre"];
        var apellido1 = respJSON["apellido1"];
        var apellido2 = respJSON["apellido2"];
        var edad = respJSON["edad"];
        document.getElementById("respAjax").innerHTML = "\n        nombre:" + nombre + " <br/>\n        apellido1:" + apellido1 + " <br/>\n        apellido2:" + apellido2 + " <br/>\n        edad:" + edad + " <br/>\n\n        ";
    }
}
